import createApp from './app'; // Caminho correto para o arquivo com a função

const app = createApp(); // Chama a função para obter a instância do app
