import { useState } from "react";

function Top1 (){
    return(
    <div className="top">
    <h1>Key Register</h1>
    </div>
    )
}

export default Top1